package login;

import java.sql.*;
import java.util.ArrayList;

public class DBconnect {

	
	public static Connection getConnection()
	{

		try
		{
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://127.0.0.1:3306/omniacant";
			String username = "root";
			String password = "";
			
			Class.forName(driver);
			
			Connection conn = DriverManager.getConnection(url,username,password);
			System.out.println("Connection erstellt");
			return conn;
		}catch(Exception e)
		{
			System.out.println(e);
			
		}
		return null;
		
	}
	public static ResultSet get(String s)
	{
		try {
			Connection con = getConnection();
			PreparedStatement statement = con.prepareStatement(s);
			ResultSet resultSet = statement.executeQuery();
			
			return resultSet;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
