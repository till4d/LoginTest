package login;

import java.util.GregorianCalendar;

public class coding {
	private String key;
	private String last;
	private boolean zweiencoder;
	
	public static String nextpart(String oldkey)
	{
		String newkey = new String();
		for (int i = 0; i < oldkey.length(); i++)
		{
			char c = 14;
			char pre,next;

			if(i==0)
				pre = oldkey.charAt(oldkey.length()-1);
			else pre = oldkey.charAt(i-1);

			if(i==oldkey.length()-1)
				next = oldkey.charAt(0);
			else next = oldkey.charAt(i+1);

			c = (char)(0xff &(byte)((byte)0xff &(int)((int)next*(int)pre)));
			if(c==0)
			{
				for (int e = 0; e < oldkey.length(); e++)
				{
					if(oldkey.charAt(i)!=(char)0)
						c = oldkey.charAt(i);
				}
			}
			newkey+=c;
		}
		return newkey;
	}
	private String scoding(String t,String key)
	{
		String fullkey = new String(key);
		String newkey = new String(key);
		while(t.length()>fullkey.length())
		{
			newkey=nextpart(newkey);
			fullkey += newkey;
		}
		String rv = new String();
		//for (int i = 0; i < fullkey.length(); i++) {
		//	System.out.println(0xff &(int)fullkey.charAt(i));
		//}
		
		
		for (int i = 0; i < t.length(); i++)
		{
			//char c = (char) ((int)t.charAt(i)+(int)fullkey.charAt(i));
			
			int x = (0xff &(int)t.charAt(i)+0xff &(int)fullkey.charAt(i));

			char c = (char)((int)0xff &((byte)t.charAt(i)+(byte)fullkey.charAt(i)));
			
			rv += c;
		}
		return rv;
	}
	
	
	
	private String sdecoding(String t,String key)
	{
		String fullkey = new String(key);
		String newkey = new String(key);
		while(t.length()>fullkey.length())
		{
			newkey=nextpart(newkey);
			fullkey += newkey;
		}
		//System.out.println(fullkey);
		String rv = new String();

		for (int i = 0; i < t.length(); i++)
		{
			//System.out.println((int)t.charAt(i)+":"+(int)fullkey.charAt(i));
			char c = (char)((int)0xff &((byte)t.charAt(i)-(byte)fullkey.charAt(i)));
			
			rv += c;
		}
		//System.out.println((int)rv.charAt(0));
		return rv;
	}

	public String encoding(String t)
	{
		String rv = new String();
		rv += scoding(t,last);
		
		if(zweiencoder)
		{
			if(t=="");
			else if(last!=t)
				last = t;
			//else last = scoding(t,key);
		}
		
		return rv;

	}
	public String decoding(String t)
	{
		String rv = new String(sdecoding(t,last));

		if(rv=="");
		else if(last!=rv)
			last = rv;
		//else{ last = scoding(rv,key);System.out.println("EROR");}

		return rv;
	}
	public coding(boolean zweiencoder)
	{
		this.zweiencoder = zweiencoder;
		String key = new String();
		
		key = Integer.toString(new GregorianCalendar().getTime().getYear());
		key += Integer.toString(new GregorianCalendar().getTime().getMonth()+1);
		key += Integer.toString(new GregorianCalendar().getTime().getDate());
		key += Integer.toString(new GregorianCalendar().getTime().getHours());
		
		key = Integer.toString((int)Integer.parseUnsignedInt(key)*Integer.parseUnsignedInt(key));
		
		//System.out.println(key);
		
		
		
		this.key = new String(key);
		this.last = new String(key);
	}
}
