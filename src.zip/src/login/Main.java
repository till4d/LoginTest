package login;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Main {
	
	static String MD5(String s)
	{
		try {
               java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
                byte[] array = md.digest(s.getBytes());
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < array.length; ++i) {
                    sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
             }
                return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            //error action
        }
        return null;
	}
	static ArrayList<String> split(String str)
	{
		ArrayList<String> rv = new ArrayList<String>();
		String push = new String();
		for (int i = 0; i < str.length(); i++) {
			
			if(str.charAt(i)=='\\')
			{
				rv.add(push);
				push = "";
				
			}else push += str.charAt(i);
		}
		rv.add(push);
		
		return rv;
		
	}
	public static String LogIn(String s)
	{
		ArrayList<String> als = new ArrayList<String>(split(s));
		String name = new String(als.get(1));
		String password = new String(als.get(2));
		System.out.println(name+"-"+password);
		
		System.out.println("SELECT * FROM `users` WHERE name=\'"+name+"\' AND password=\'"+MD5(password)+"\'");
		ResultSet resultSet = DBconnect.get("SELECT * FROM `users` WHERE name=\'"+name+"\' AND password=\'"+MD5(password)+"\'");
		
		String rv = new String("");
		try {
			if(resultSet.next())
					rv = "LogIn\\";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rv;
	}
	public static void main(String[] args) {
		coding co = new coding(true);
		ServerSocket server = null;
		try {
			server = new ServerSocket(12345);
			Socket client = server.accept();
			
			OutputStream outputStream = client.getOutputStream();
			InputStream inputStream = client.getInputStream();
			
			PrintWriter writer = new PrintWriter(outputStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			
			
			String output = null;

			System.out.println("start");
	

			
			//while((output = bufferedReader.readLine())!=null)
			{
				output = bufferedReader.readLine();
				//co.decoding(Escaper.NEscape(output)));
				String a = new String(co.decoding(Escaper.NEscape(output)));
				System.out.println("User sagt:"+a);
				writer.println(Escaper.Escape(co.encoding(LogIn(a))));
				writer.flush();
				writer.close();
			}
			bufferedReader.close();
			server.close();
			server = null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("hier");
		
		if(server!=null)
			try {
				server.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}
