package login;

public class Escaper {
	public static String NEscape(String s)
	{
		String rv = new String();
		
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)=='\\')
			{
				i++;
				if(s.charAt(i)=='\\')
					rv += '\\';
				else 
					{
						String str = new String();
						str += s.charAt(i);
						i++;
						str += s.charAt(i);
						i++;
						str += s.charAt(i);
						int x = Integer.parseInt(str);
						rv+= (char)x;
					
					}
			}else rv += s.charAt(i);
		}
		return rv;
	}
	public static String Escape(String s)
	{
		String rv = new String();
		for (int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i)=='\\')
				rv += "\\\\";
			else if((char)s.charAt(i)<=32||(char)s.charAt(i)>=127)
			{
				String l = Integer.toString((int)s.charAt(i));
				if(l.length()==1)
					l = "00"+l;
				if(l.length()==2)
					l = "0"+l;
				rv += "\\"+l;
			}
			else rv += s.charAt(i);
		}
		return rv;
	}
}
